# Adding new key/value pairs

alien_0 = {"color": "green", "points": 5}
alien_0["x_position"] = 0
alien_0["y_position"] = 0
print(alien_0)