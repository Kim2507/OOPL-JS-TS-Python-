# Let's see what happens when we try keys that don't exist
alien_0 = {"color": "green", "points": 5}

print(alien_0["colour"])