filename = 'data/pi_digits.txt'

# Open the file and read everything in one big gulp.
with open(filename) as f:
    print(type(f))
    #print(f)
    #content = f.read()
#print(content)
