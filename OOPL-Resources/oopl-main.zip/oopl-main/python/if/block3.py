# Checking if an element exists in a list
banned_users = ['andrew', 'carolina', 'david']
user = 'andrew'

if user in banned_users:
    print("You are blocked!")
else:
    print("Please proceed!")
