# A simple Python List

fruits = ["orange", "apple", "banana"]
print(fruits)
