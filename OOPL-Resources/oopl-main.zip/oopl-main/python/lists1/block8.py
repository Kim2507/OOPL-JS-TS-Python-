# Permanently Reverse Sorting a List

fruits = ["orange", "apple", "banana"]
print(fruits)

fruits.sort(reverse=True)
print(fruits)