# Find the Length of a List

fruits = ["orange", "apple", "banana"]
num_items = len(fruits)
print(num_items)