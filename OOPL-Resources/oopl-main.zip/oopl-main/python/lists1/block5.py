# Popping Elements from a List

fruits = ["orange", "apple", "banana"]
print(fruits)

last_fruit = fruits.pop()
print(f"Yummy {last_fruit}!")