# Modifying Elements in a List

fruits = ["orange", "apple", "banana"]
print(fruits)

# Let's change item 1
fruits[1] = "kiwi"
print(fruits)