# Temporarily Sorting a List

fruits = ["orange", "apple", "banana"]
sorted_fruits = sorted(fruits)
print(fruits)
print(sorted_fruits)