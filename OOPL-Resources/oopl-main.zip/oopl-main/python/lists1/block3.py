# Appending Elements to a List

fruits = ["orange", "apple", "banana"]
print(fruits)

# Let's add a kiwi!
fruits.append("kiwi")
print(fruits)