# Accessing Elements in a List

fruits = ["orange", "apple", "banana"]
print(fruits[0])
print(fruits[1])
print(fruits[2])

# Let's try negative indexing!
print(fruits[-1])