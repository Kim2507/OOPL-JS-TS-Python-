# Removing Elements from a List

fruits = ["orange", "apple", "banana"]
print(fruits)

# Let's remove item 1
del fruits[1]
print(fruits)