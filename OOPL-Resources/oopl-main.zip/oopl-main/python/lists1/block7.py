# Permanentaly Sorting a List

fruits = ["orange", "apple", "banana"]
print(fruits)

fruits.sort()
print(fruits)