# Gather user input via the input() method

name = input("What's your name?  ")
print(f"\nHello, {name}!")