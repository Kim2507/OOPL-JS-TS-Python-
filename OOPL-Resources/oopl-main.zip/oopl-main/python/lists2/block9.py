# We can do this same thing in just one line of code!
# This is called a list comprehension
squares = [i * i for i in range(10)]
print(squares)