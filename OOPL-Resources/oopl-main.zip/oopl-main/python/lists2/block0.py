# We can easily iterate through all the
# elements in a list via a for loop
people = ['adbi', 'mustafa', 'kim'] 
for person in people: 
    print(f"Welcome, {person} to the class!")
    
print("Hope you have a great semester!")