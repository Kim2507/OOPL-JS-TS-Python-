# Let's find all the squares from 0 to 10.
# Here is one way to do this.
squares = []
for i in range(10):
    squares.append(i * i)
print(squares)