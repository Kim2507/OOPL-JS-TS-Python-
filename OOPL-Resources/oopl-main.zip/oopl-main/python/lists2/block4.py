# Illustrates how to extract an array slice
people = ['adbi', 'mustafa', 'david', 'kim', 'alex']  

print("Here's a slice:'")
for person in people[:-2]:
    print(person.title())
