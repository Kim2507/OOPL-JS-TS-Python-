person = "bill gates"
print(person)
print(person.upper())
print(person.lower())
print(person.title())