product = "iPad Pro"
cost = 699.99

print (f"The item: {product} costs {cost}.")
