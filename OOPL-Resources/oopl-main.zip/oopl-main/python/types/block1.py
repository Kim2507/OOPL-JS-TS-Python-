# string
msg = "hello"

# int
num_items = 4

# float
distance = 10.2

print(msg, num_items, distance)