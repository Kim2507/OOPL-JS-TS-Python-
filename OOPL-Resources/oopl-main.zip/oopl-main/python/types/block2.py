msg = "hello"
num_items = 4
distance = 10.2

print(type(msg))
print(type(num_items))
print(type(distance))