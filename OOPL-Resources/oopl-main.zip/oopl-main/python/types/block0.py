thing = "hello"
print(thing)

thing = 5.12
print(thing)