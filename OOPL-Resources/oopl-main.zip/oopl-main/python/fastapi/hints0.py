
name: str = "Mark"
age: int = 22

print(f"{name} is {age} years old.")

