# Example of PEP-484 Type Hints

def add(a: int, b:int) -> int:
    return a + b

sum = add(4,5)
print(sum)

