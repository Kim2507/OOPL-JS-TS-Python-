# Functions can also return values.
# You can return anything you want from a function.
# e.g. a number, a list, a dict, etc.

def add (x, y):
    return x + y

sum = add(5, 2)
print(sum)