# Simplest possible function.
# Note the docstring under greet_user!

def greet_user():
    """Display a greeting!"""
    print("Hello!")

greet_user()