# Let's cause an error!
print (5/0)