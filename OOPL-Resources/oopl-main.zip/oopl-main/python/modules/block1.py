# Import alias example
import pizza as pz

pz.make_pizza(16, 'pepperoni')
pz.make_pizza(12, 'mushrooms', 'green peppers', 'extra cheese')