//  Example Function with parameters and return value.
function add (a: number, b: number): number {
    return (a + b);
}

let sum = add (2, 5)
console.log(sum)

