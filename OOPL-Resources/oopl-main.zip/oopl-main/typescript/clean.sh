rm *.js
