//  Example Function with String parameter and no return value
function log_msg (msg: string): void {
    console.log(msg);
}

log_msg("Hello")
