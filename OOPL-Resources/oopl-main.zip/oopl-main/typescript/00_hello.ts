// Hello, TypeScript!
// Wow, this looks just like JavaScript!
console.log("Hello, World!");