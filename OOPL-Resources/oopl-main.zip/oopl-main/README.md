# oopl
OOPL Code Blocks

Many of the Python examples are derived from:  https://nostarch.com/pythoncrashcourse2e