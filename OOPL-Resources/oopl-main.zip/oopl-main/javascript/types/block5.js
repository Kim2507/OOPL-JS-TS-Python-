'use strict';

// You can define objects with properties.
// JavaScript doesn't define dictionaries, but objects
// are very similar.
let person = {
    firstName: "Ethan",
    lastName: "Cerami"
};

//  Let's see what we get back...
console.log (typeof person);
console.log (person);
console.log (person.firstName);
console.log (person.lastName);
