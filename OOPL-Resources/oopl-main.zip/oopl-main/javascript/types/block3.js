'use strict';
let activeUser = true;

console.log(typeof activeUser);