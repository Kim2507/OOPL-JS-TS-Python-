'use strict';
// In JavaScript, we use typeof to
// determine the type of each variable.

//  String variable.
let firstName = "Ethan";
console.log(typeof firstName);

//  Number Variable
let totalPrice = 159.22;
console.log(typeof totalPrice);

// Boolean Variable
let activeUser = false;
console.log(typeof activeUser)

