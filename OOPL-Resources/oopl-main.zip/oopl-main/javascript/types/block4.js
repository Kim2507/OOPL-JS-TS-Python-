'use strict';
// Set Product to Something...
let product = "Milk"

// Later on, set it to null
product = null;
console.log(product);