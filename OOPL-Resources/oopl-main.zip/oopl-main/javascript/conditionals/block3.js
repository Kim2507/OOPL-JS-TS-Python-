'use strict';

//  Example while loop.
let count = 0;
while (count < 5) {
    console.log(count);
    count++;
}