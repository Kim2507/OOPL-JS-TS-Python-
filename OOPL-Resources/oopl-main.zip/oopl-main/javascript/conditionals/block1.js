'use strict';
let price = 25;

// This is an example ternary operator.
// You can think of it as a compact if/else statement.
let message = (price > 10) ? "expensive" : "cheap";
console.log(message);