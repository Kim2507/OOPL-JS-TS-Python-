'use strict';

// Example for loop.
for (let i=0; i<10; i++) {
    console.log(i);
}