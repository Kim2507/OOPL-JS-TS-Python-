'use strict';

// Basic Array Example
let values = ['a', 'b', 'c'];
console.log(values);
console.log(values[0]);
console.log(values.length);

// Push Example
values.push('d');
console.log(values);

// Pop Example
let last = values.pop()
console.log(last);
console.log(values);

