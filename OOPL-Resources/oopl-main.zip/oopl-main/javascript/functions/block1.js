'use strict';

// Example of Math Functions
console.log(Math.abs(-42));
console.log(Math.sqrt(4));