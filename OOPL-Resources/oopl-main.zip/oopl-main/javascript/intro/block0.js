'use strict';
// Hello, JavaScript!
console.log("Hello, World!");
