'use strict';
// For constants, use const, instead of let
const PI = 3.14;
console.log(PI);