'use strict';
// In JavaScript, we use the "let" keyword
// to declare variables.

//  String variable.
let firstName = "Ethan";
console.log("Hello, " + firstName + "!");

//  Number Variable
let totalPrice = 159.22;
console.log("Total Price:  " + totalPrice);

// Boolean Variable
let activeUser = false;
console.log("User is active:  " + activeUser);