'use strict';
// A lot of older/legacy Javascript code
// use var to declar variables.
// AVOID doing this;  use let instead.

//  This will work, but AVOID it; and use let instead.
var firstName = "Ethan";
console.log("Hello, " + firstName + "!");