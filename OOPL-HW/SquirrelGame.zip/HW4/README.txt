﻿Game: Killing Evil ( updated from Aliens Invasion)

 Description: Updated from Aliens Invasion by adding sound effects, background image, add some other game elements 

The game includes 2 elements which are evils and squirrels
	Rules: Shoot evils before they comes to the bottom and hit ship without shooting squirrels, if you shoot any squirrel, then program will exit immediately.
	You will LOST if : you shoot any squirrels on the screen or evils hit bottom of the screen
	You will WIN if you shoot all the evils before they reach bottom of the screen    
