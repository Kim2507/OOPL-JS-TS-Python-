from breaking_news import NewYorkTimesBreakingNews
from subscriber import *

nyt =NewYorkTimesBreakingNews()

business_subscriber= BusinessNewsSubscriber()
nyt.attach(business_subscriber)

politic_subscriber = PoliticsNewsSubscriber()
nyt.attach(politic_subscriber)

subscriber_c = KeyWordSubscriber("Biden")
nyt.attach(subscriber_c)


nyt.publish_news_item("business","Facebook goes down...")
nyt.publish_news_item("politics","Biden calls for debt limit...")

