"""A module named breaking_news.py.
This module will need a class called Publisher with attach()
and detach() methods.  Hint:  see our code from class.
It will also need a class called NewYorkTimesBreakingNews, which extends Publisher. """
from abc import ABC, abstractmethod
class Publisher(ABC):
    """Declares a set of methods for managing subscribers."""
    @abstractmethod
    def attach(self, subscriber):
        """Attach a subscriber to the publisher."""
        pass

    @abstractmethod
    def detach(self, subscriber):
        """Detach a subscriber from the publisher."""
        pass

"""def publish_news_item(self, news_category, news_title)
def notify(self, news_category, news_title)
"""
class NewYorkTimesBreakingNews(Publisher):
    "New York Times Breaking News Publisher"

    """Initialize New York Time Pulisher """
    def __init__(self):
        self._state = "New York"
        self._subscriber = []
        self._category =[]
        self._news_title=[]

    #Pulish new item, add to category list and title list
    #then notify to all publishers
    def publish_news_item(self,news_category,news_title):
        self._category.append(news_category)
        self._news_title.append(news_title)
        print(f"NYT: Breaking news: {news_title} [category={news_category}]")
        self.notify(news_category,news_title)


    def attach(self, subscriber):
        """Attach a new subscriber."""
        self._subscriber.append(subscriber)


    def detach(self, subscriber):
        """Detach the specified subscriber."""
        self._subscriber.remove(subscriber)

    def notify(self, news_category, news_title):
        """Notify all subscribers..."""
        print("NYT: Notifying subscribers...")
        for subscriber in self._subscriber:
            subscriber.breaking_news(news_category,news_title)

