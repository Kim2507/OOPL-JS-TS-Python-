from abc import ABC, abstractmethod


class Subscriber(ABC):
    """The Subscriber listens for events."""

    @abstractmethod
    def breaking_news(self, news_category, news_title):
        """Receive news category and title ."""
        pass



class BusinessNewsSubscriber(Subscriber):
    """Concrete Business News Subscriber."""

    def breaking_news(self, news_category, news_title):
        """React to category business only."""
        if news_category =='business':
            print(f"SUBSCRIBER: Business Breaking: {news_title}")


class PoliticsNewsSubscriber(Subscriber):
    """Politics News Subcriber."""
    def breaking_news(self, news_category, news_title):
        """React to category politics only."""
        if news_category == 'politics':
            print(f"SUBSCRIBER: Politics Breaking: {news_title}")

class KeyWordSubscriber(Subscriber):
    def __init__(self,key):
        self.key = key.lower()
    def breaking_news(self, news_category, news_title):
        """React to any match key word ."""
        if (self.key in news_category) \
                or (self.key in news_title.lower()):
            print(f"Fillter: [{self.key}] : {news_title}")

