
"""Programmer: Kim Trinh
Last update: 09/28/2021"""
class SocialMedia:
    """Model SocialMedia platform"""
    def __init__(self,platform_name,platform_url):
        self.platform_name = platform_name
        self.platform_url = platform_url

    def post_message(self,msg):
        msg ="Posting not implemented in base class."
        print(msg)

"""Twitter, one for Facebook, and one for LinkedIn"""
class Twitter(SocialMedia):
    """Twitter model"""
    def __init__(self,platform_name="Twitter",platform_url="https://www.twitter.com/"):
        super().__init__(platform_name,platform_url)

    #Posting a message with checking
    def post_message(self,msg):
        len_msg=int(len(msg))
        if len_msg<=80:
            print(f"Posting message to Twitter: {msg}")
        else:
            print("Message is too long")

class Facebook(SocialMedia):
    """Facebook model"""
    def __init__(self,platform_name="Facebook",platform_url="https://www.facebook.com/"):
        super().__init__(platform_name,platform_url)

    #Posting a message
    def post_message(self,msg):
        print(f"Posting message to all your friends on Facebook: {msg}")

class LinkedIn(SocialMedia):
    """LinkedIn model"""
    def __init__(self,platform_name="LinkedIn",platform_url="https://www.linkedin.com/"):
        super().__init__(platform_name,platform_url)

    #Posting a message
    def post_message(self,msg):
        print(f"Posting message to all your colleagues on LinkedIn: {msg}")






