from media import Twitter,Facebook,LinkedIn
# Creating message
my_mess = "I want to be proficient in Python"
long_mess = "There is no hunting like the hunting of man,"\
            "and those who have hunted armed men long enough and liked it, "\
            "never care for anything else thereafter."
# Creating twitter message
my_twitter = Twitter()
#Posing message to Twitter
my_twitter.post_message(my_mess)
invalid_twitter = Twitter()
invalid_twitter.post_message(long_mess)

# Creating Facebook's message and posting message to Facebook
my_facebook = Facebook()
my_facebook.post_message(my_mess)

#Creating LinkedIn's message and posting message to LinkedIn
my_linkedIn = LinkedIn()
my_linkedIn.post_message(my_mess)

